/**
 * Handler that will be called during the execution of a PostLogin flow.
 *
 * @param {Event} event - Details about the user and the context in which they are logging in.
 * @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
 */
exports.onExecutePostLogin = async (event, api) => {
	//Skip MFA requirement for client name
	const CLIENTS_WITHOUT_MFA = ["myapp User Verification"];

	if (CLIENTS_WITHOUT_MFA.includes(event.client.name)) {
		console.log(
			`[mfa-enforce] skipping mfa for client_id: ${event.client.name}`
		);
		return;
	}
	//Skip MFA requirement for client name

	// check if MFA was already enforced in this session
	const mfaCompletedInSession = event.authentication?.methods.find(
		({ name }) => name === "mfa"
	);
	console.log(`[mfa-enforce] mfaCompletedInSession: ${mfaCompletedInSession}`);

	console.log("****************************");
	const is_privileged = event.request.query.privileged;
	const authenticatorChoice =
		event.user.app_metadata.authenticator_choice || "otp";

	// check if user is in registration journey
	const isRegistrationInProgress =
		!!event.user.app_metadata.registration_in_progress;
	console.log(
		`[mfa-enforce] isRegistrationInProgress: ${isRegistrationInProgress}`
	);

	const isPhoneVerificationPending =
		event.user.app_metadata.verification_pending_phone;

	if (authenticatorChoice == "phone" && isPhoneVerificationPending) {
		console.log(`[mfa-enforce] choice skipping MFA enforcement`);
		return;
	}

	if (
		!is_privileged &&
		(mfaCompletedInSession ||
			isRegistrationInProgress ||
			isPhoneVerificationPending)
	) {
		console.log(`[mfa-enforce] skipping MFA enforcement`);
		return;
	}
	console.log("outside skip mfa");
	// is user enrolled in preferred authenticator?

	console.log("enrolled factors:", event.user.enrolledFactors);

	console.log("authenticator_choice : " + authenticatorChoice);
	console.log("authenticator factors: ", event.user.enrolledFactors);
	console.log(
		"authenticator filter: " +
			event.user.enrolledFactors?.filter((f) => f.type === authenticatorChoice)
	);
	const userNotEnrolledInPreferredAuthenticator =
		event.user.enrolledFactors?.filter((f) => f.type === authenticatorChoice)
			.length === 0;
	console.log(
		`[mfa-enforce] userNotEnrolledInPreferredAuthenticator: ${userNotEnrolledInPreferredAuthenticator}`
	);

	// we want to avoid user being displayed an enrollment screen for phone authenticator
	// also, we have already handled enrollment for otp authenticator in the previous action
	// so, at this point if user is not enrolled in their preferred authenticator, then deny access
	if (userNotEnrolledInPreferredAuthenticator) {
		console.log(
			`[mfa-enforce] userNotEnrolledInPreferredAuthenticator: ${userNotEnrolledInPreferredAuthenticator}`
		);
		api.access.deny("user is not enrolled in preferred authenticator");
	}

	// we have handled the condition previously where user is not enrolled in preferred authenticator
	// so here we can simply challenge the user with their preferred authenticator
	console.log(`[mfa-enforce] enforce mfa: ${authenticatorChoice}`);

	if (is_privileged) {
		//console.log("******has privileged*******")
		//console.log(event.query.is_privileged)
		api.idToken.setCustomClaim("privileged", true);

		api.multifactor.enable("any", { allowRememberBrowser: false });
		api.authentication.challengeWith({ type: `${authenticatorChoice}` });
	} else {
		console.log("******else has privileged*******");
		api.multifactor.enable("any", { allowRememberBrowser: false });
		api.authentication.challengeWith(
			{ type: `${authenticatorChoice}` },
			{ additionalFactors: [{ type: "email" }] }
		);
	}
};

/**
 * Handler that will be invoked when this action is resuming after an external redirect. If your
 * onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
 *
 * @param {Event} event - Details about the user and the context in which they are logging in.
 * @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
 */
// exports.onContinuePostLogin = async (event, api) => {
// };
