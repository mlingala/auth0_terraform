/**
 * Handler that will be called during the execution of a SendPhoneMessage flow.
 *
 * @param {Event} event - Details about the user and the context in which they are logging in.
 * @param {SendPhoneMessageAPI} api - Methods and utilities to help change the behavior of sending a phone message.
 */

const lib = require("messagemedia-messages-sdk");

exports.onExecuteSendPhoneMessage = async (event, api) => {
	const text = event.message_options.text;
	const action = event.message_options.action;
	const recipient = event.message_options.recipient;
	const userName = event.user.username;
	const sourceNumber = "fabrikam";

	/* Basic Auth */
	lib.Configuration.basicAuthUserName = event.secrets.MESSAGEMEDIA_USERNAME;
	lib.Configuration.basicAuthPassword = event.secrets.MESSAGEMEDIA_PASSWORD;

	var controller = lib.MessagesController;
	let body = new lib.SendMessagesRequest();
	body.messages = [];
	body.messages[0] = new lib.Message();

	body.messages[0].content = text;
	body.messages[0].destinationNumber = recipient;
	body.messages[0].sourceNumber = sourceNumber;

	controller.sendMessages(body, function (error, response, context) {
		console.log(response);
		if (error) {
			console.log(
				"Unable to send SMS; User ID:" + userName + "; Action: " + action
			);
			console.log(error);
		}
	});
};
