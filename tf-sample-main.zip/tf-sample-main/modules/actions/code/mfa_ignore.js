/**
* Handler that will be called during the execution of a PostChangePassword flow.
*
* @param {Event} event - Details about the user and the context in which the change password is happening.
* @param {PostChangePasswordAPI} api - Methods and utilities to help change the behavior after a user changes their password.
*/
exports.onExecutePostChangePassword = async (event, api) => {
  console.log(`[mfa-ignore] inside action`);
//set email verified to false if the email verified is true during registration procedure

    const ManagementClient = require('auth0').ManagementClient;
    const management = new ManagementClient({
        domain: event.secrets['AUTH0_DOMAIN'],
        clientId: event.secrets['AUTH0_CLIENT_ID'],
        clientSecret: event.secrets['AUTH0_CLIENT_SECRET']
    });

    try {
      const params = {id: event.user.user_id};
      const user = await management.users.get(params);
      const appMetadata = user.data.app_metadata;
      console.log(appMetadata);

      if(appMetadata && (appMetadata.registration_in_progress)
          || (!appMetadata.registration_in_progress && appMetadata.verification_pending_phone)){
          console.log(`[mfa-ignore] set auth0 email verified to false`);
          const data = { email_verified: false };
          const params =  { id : event.user.user_id};
          await management.users.update(params, data)
      }
    }catch (e) {
      console.log(e);
    }

};