/**
 * Handler that will be called during the execution of a PreUserRegistration flow.
 *
 * @param {Event} event - Details about the context and user that is attempting to register.
 * @param {PreUserRegistrationAPI} api - Interface whose methods can be used to change the behavior of the signup.
 */
exports.onExecutePreUserRegistration = async (event, api) => {
	const fetch = require("node-fetch");
	const bypassValidation = false;
	const client_id = event.client.client_id;
	const client_name = event.client.name;

	console.log(client_id);
	console.log(client_name);

	if (client_name != "myapp") {
		return;
	}

	const email = event.user.email;
	const postCode = event.request.body["ulp-post-code"];
	const terms = event.request.body["ulp-terms-of-use"];
	const emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

	if (!postCode || postCode.length != 4) {
		api.validation.error(
			"invalid_payload",
			"Invalid Post Code. Please enter a 4 digit post code that matches details on the policy."
		);
		return;
	} else if (!terms) {
		api.validation.error(
			"invalid_payload",
			"Please accept terms of use to proceed"
		);
		return;
	}

	try {
		if (!bypassValidation) {
			// external system API endpoint
			const url =
				event.secrets.BASE_URL +
				"/Policy/Validate/" +
				event.secrets.PARTNER_CODE +
				"/" +
				email +
				"/" +
				postCode;

			// GET request to the UPM API
			const response = await fetch(url, {
				method: "GET",
				headers: {
					"Content-Type": "application/json",
					Authorization:
						"Basic " +
						Buffer.from(
							event.secrets.API_KEY + ":" + event.secrets.APPLICATION_ID
						).toString("base64"),
				},
			});

			// response
			const data = await response.json();

			// If the email, policy and dob do not match, deny the registration
			if (!data.hasRegistered) {
				console.log(
					`[verify-registration-details] The provided information does not match our records`
				);
				api.validation.error(
					"invalid_payload",
					"There was a problem creating your account. Please call 1300 855 663."
				);
			} else {
				// match successful
				console.log(
					`[verify-registration-details] rego details matched, proceed`
				);
				api.user.setAppMetadata("registration_in_progress", true);
				api.user.setAppMetadata("verification_pending_email", true);
				api.user.setAppMetadata("verification_pending_phone", false);
				api.user.setAppMetadata("migrated_user", false);
				api.user.setAppMetadata("partner_number", data.policy.partnerNumber);
				api.user.setAppMetadata("contact_id", data.policy.contactId);

				var phoneNumberOnFile = data.policy.phoneNumber;
				if (phoneNumberOnFile != null) {
					if (phoneNumberOnFile.startsWith("+61")) {
						console.log(
							`[verify-registration-details] save phone number on user profile`
						);
						api.user.setAppMetadata("phone_number", phoneNumberOnFile);
					} else if (
						!phoneNumberOnFile.startsWith("+61") &&
						phoneNumberOnFile.startsWith("04")
					) {
						phoneNumberOnFile = "+61" + phoneNumberOnFile.substring(1);
						console.log(
							`[verify-registration-details] save phone number on user profile`
						);
						api.user.setAppMetadata("phone_number", phoneNumberOnFile);
					} else {
						console.log(
							`[verify-registration-details] invalid phone number on file, require OTP enrollment`
						);
						//disable Authenticator app as MFA option - myapp-1161
						// api.user.setAppMetadata("authenticator_choice", "otp");
					}
				} else {
					console.log(
						`[verify-registration-details] no phone number on file, require OTP enrollment`
					);
					//disable Authenticator app as MFA option - myapp-1161
					// api.user.setAppMetadata("authenticator_choice", "otp");
				}
				console.log(
					`[verify-registration-details] proceed with post login actions`
				);
			}
		} else {
			api.user.setAppMetadata("registration_in_progress", true);
		}
	} catch (error) {
		api.validation.error(
			"invalid_payload",
			"An error occurred while verifying your details. Please contact support."
		);
	}
};
