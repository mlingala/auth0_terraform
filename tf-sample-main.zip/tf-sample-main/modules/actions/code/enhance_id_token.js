/**
 * Handler that will be called during the execution of a PostLogin flow.
 *
 * @param {Event} event - Details about the user and the context in which they are logging in.
 * @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
 */
exports.onExecutePostLogin = async (event, api) => {
	const namespace = "https://myappmiddlewareapi/claims/";
	// for now dumping the whole app_metadata object
	// TBD: pick particular fields not the whole object
	//api.idToken.setCustomClaim(`${namespace}app_metadata`, event.user.app_metadata);

	api.accessToken.setCustomClaim(
		namespace + "permission",
		"read:policy write:token"
	);

	if (typeof event.user.app_metadata.contact_id !== "undefined") {
		api.accessToken.setCustomClaim(
			namespace + "contactid",
			event.user.app_metadata.contact_id
		);
	}

	if (typeof event.user.app_metadata.partner_number !== "undefined") {
		api.accessToken.setCustomClaim(
			namespace + "partnernumber",
			event.user.app_metadata.partner_number
		);
	}

	if (typeof event.user.email !== "undefined") {
		api.accessToken.setCustomClaim(namespace + "email", event.user.email);
	}

	if (
		typeof event.user.app_metadata.verification_pending_email !== "undefined"
	) {
		api.idToken.setCustomClaim(
			namespace + "verification_pending_email",
			event.user.app_metadata.verification_pending_email
		);
	}

	if (
		typeof event.user.app_metadata.verification_pending_phone !== "undefined"
	) {
		api.idToken.setCustomClaim(
			namespace + "verification_pending_phone",
			event.user.app_metadata.verification_pending_phone
		);
	}

	if (typeof event.user.app_metadata.registration_in_progress !== "undefined") {
		api.idToken.setCustomClaim(
			namespace + "registration_in_progress",
			event.user.app_metadata.registration_in_progress
		);
	}

	if (typeof event.user.app_metadata.phone_number !== "undefined") {
		api.idToken.setCustomClaim(
			namespace + "phone_number",
			event.user.app_metadata.phone_number
		);
	}

	if (typeof event.user.app_metadata.authenticator_choice !== "undefined") {
		api.idToken.setCustomClaim(
			namespace + "authenticator_choice",
			event.user.app_metadata.authenticator_choice
		);
	}

	if (typeof event.user.app_metadata.migrated_user !== "undefined") {
		api.idToken.setCustomClaim(
			namespace + "migrated_user",
			event.user.app_metadata.migrated_user
		);
	}
};

/**
 * Handler that will be invoked when this action is resuming after an external redirect. If your
 * onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
 *
 * @param {Event} event - Details about the user and the context in which they are logging in.
 * @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
 */
// exports.onContinuePostLogin = async (event, api) => {
// };
