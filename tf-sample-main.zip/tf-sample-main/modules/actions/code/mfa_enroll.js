/**
* Handler that will be called during the execution of a PostLogin flow.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// check if we need to enforce authenticator-app enrollment
exports.onExecutePostLogin = async (event, api) => {

//set email verified to false if the email verified is true during registration procedure
if(event.user.app_metadata.registration_in_progress && event.user.email_verified) {
  console.log(`[mfa-enroll] revert email verified`);
  const ManagementClient = require('auth0').ManagementClient;
  const management = new ManagementClient({
    domain: event.secrets['AUTH0_DOMAIN'],
    clientId: event.secrets['AUTH0_CLIENT_ID'],
    clientSecret: event.secrets['AUTH0_CLIENT_SECRET']
    });
    const data = { email_verified: false };
    const params =  { id : event.user.user_id};
    await management.users.update(params, data)
}

  // does user prefer otp authenticator?
  const userPreferredAuthenticatorIsOtp = event.user.app_metadata.authenticator_choice === "otp";
  console.log(`[mfa-enroll] userPreferredAuthenticatorIsOtp: ${userPreferredAuthenticatorIsOtp}`);

  // is user enrolled in otp authenticator?
  const userNotEnrolledInOtp = event.user.enrolledFactors?.filter(f => f.type === "otp").length === 0;
  console.log(`[mfa-enroll] userNotEnrolledInOtp: ${userNotEnrolledInOtp}`);

  const isRegistrationInProgress = event.user.app_metadata.registration_in_progress;
  const isEmailVerificationPending = event.user.app_metadata.verification_pending_email;
  const isPhoneVerificationPending = event.user.app_metadata.verification_pending_phone;

  // conditionally force enrollment
  // Raj - To add registration in progress check for first login
  if(userPreferredAuthenticatorIsOtp && userNotEnrolledInOtp && !isEmailVerificationPending) {
    // user must enroll in otp (i.e. authenticator-app)
    console.log(`[mfa-enroll] enrollWith: "otp"`);
    api.authentication.enrollWith({ type: "otp" });

    const userEmailVerified = event.user.email_verified;

    if(!isEmailVerificationPending && !userEmailVerified){
      // If email_verified false; Set email_verified to true;
      const ManagementClient = require('auth0').ManagementClient;
      const management = new ManagementClient({
              domain: event.secrets['AUTH0_DOMAIN'],
              clientId: event.secrets['AUTH0_CLIENT_ID'],
              clientSecret: event.secrets['AUTH0_CLIENT_SECRET']
      });

      const data = { email_verified: true };
      const params =  { id : event.user.user_id};

      try {
          api.user.setAppMetadata("registration_in_progress", false);
          await management.users.update(params, data)
      } catch (e) {
          // handle

      }
    }
  } else {
    console.log(`[mfa-enroll] skip mfa enrollment`);
  }

  console.log(event.request);
  const operation = event.request.query.operation;

  if(operation && operation=="change_phone"){
    api.user.setAppMetadata("verification_pending_phone", true);
  }
  console.log("completed mfa enroll");
};

/**
* Handler that will be invoked when this action is resuming after an external redirect. If your
* onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// exports.onContinuePostLogin = async (event, api) => {
// };